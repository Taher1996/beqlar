return {
    frames = {
        {
            x = 0,
            y = 0,
            width = 544,
            height = 512
        },
        {
            x = 544,
            y = 0,
            width = 544,
            height = 512
        },
        {
            x = 1088,
            y = 0,
            width = 544,
            height = 512
        },
        {
            x = 0,
            y = 512,
            width = 544,
            height = 512
        },
        {
            x = 544,
            y = 512,
            width = 544,
            height = 512
        },
        {
            x = 1088,
            y = 512,
            width = 544,
            height = 512
        },
        {
            x = 0,
            y = 1024,
            width = 544,
            height = 512
        }
    }
}