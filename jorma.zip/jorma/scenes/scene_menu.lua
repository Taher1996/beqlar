-- Menu Scene (Optimized)
local composer = require("composer")
local scene = composer.newScene()

function scene:create(event)
    local sceneGroup = self.view

    -- Screen dimensions
    local screenW = display.contentWidth
    local screenH = display.contentHeight

    -- Background
    local backGround = display.newImageRect("images/muutkuvat/paav/pvdr.png", screenW, screenH)
    backGround.x = display.contentCenterX
    backGround.y = display.contentCenterY
    sceneGroup:insert(backGround)

    -- Start button
    local startButton = display.newImageRect("images/muutkuvat/paav/Start_Nappi.png", 200, 60)
    startButton.x = display.contentCenterX
    startButton.y = 300
    sceneGroup:insert(startButton)

    -- Quit button
    local quitButton = display.newRect(display.contentCenterX, 400, 200, 60)
    quitButton:setFillColor(0.8, 0.2, 0.2)
    sceneGroup:insert(quitButton)

    local quitText = display.newText("QUIT GAME", display.contentCenterX, 400, native.systemFont, 36)
    quitText:setFillColor(1, 1, 1)
    sceneGroup:insert(quitText)

    -- Sound icon
    local soundIcon = display.newRect(screenW - 50, 50, 60, 60)
    soundIcon:setFillColor(0.3, 0.3, 0.3)
    sceneGroup:insert(soundIcon)

    local soundText = display.newText("🔊", screenW - 50, 50, native.systemFont, 36)
    soundText:setFillColor(1, 1, 1)
    sceneGroup:insert(soundText)

    -- Event handlers
    local function onStartButtonPress(event)
        if event.phase == "ended" then
            composer.gotoScene("scenes.scene_main", {effect = "slideLeft", time = 300})
        end
        return true
    end

    local function onQuitButtonPress(event)
        if event.phase == "ended" then
            native.requestExit()
        end
        return true
    end

    local function onSoundIconPress(event)
        if event.phase == "ended" then
            print("Sound settings (coming soon)")
        end
        return true
    end

    -- Add listeners
    startButton:addEventListener("touch", onStartButtonPress)
    quitButton:addEventListener("touch", onQuitButtonPress)
    soundIcon:addEventListener("touch", onSoundIconPress)
end

scene:addEventListener("create", scene)

return scene