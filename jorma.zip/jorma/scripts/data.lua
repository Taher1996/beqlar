-- Player movement module (without physics conflicts)
local playerMovement = {}

-- Boundaries
local MIN_Y = 490
local MAX_Y = display.contentHeight - 50

-- Jump variables
local isJumping = false
local jumpVelocity = 0
local JUMP_POWER = -25
local GRAVITY = 0.8

-- Check tile collision
local function checkTileCollision(character, tiles)
    if not tiles then return false, nil end

    local charLeft = character.x - 50
    local charRight = character.x + 50
    local charBottom = character.y + 128

    for i = 1, #tiles do
        local tile = tiles[i]
        if tile then
            local tileLeft = tile.x - 50
            local tileRight = tile.x + 50
            local tileTop = tile.y - 20
            local tileBottom = tile.y + 20

            if charBottom >= tileTop and charBottom <= tileBottom + 10 and
               charRight > tileLeft and charLeft < tileRight then
                return true, tile.y - 128
            end
        end
    end

    return false, nil
end

-- Player movement update
function playerMovement.update(character, keysPressed, currentSequence, speed, tiles)
    local moveX = 0
    local moveY = 0
    local newSequence = nil

    -- Horizontal movement
    if keysPressed["right"] or keysPressed["d"] then
        moveX = speed
    end
    if keysPressed["left"] or keysPressed["a"] then
        moveX = -speed
    end

    -- Vertical movement (when not jumping)
    if not isJumping then
        if keysPressed["up"] or keysPressed["w"] then
            moveY = -speed
        end
        if keysPressed["down"] or keysPressed["s"] then
            moveY = speed
        end
    end

    -- Jump
    if (keysPressed["space"]) and not isJumping then
        isJumping = true
        jumpVelocity = JUMP_POWER
    end

    -- Apply gravity
    if isJumping then
        jumpVelocity = jumpVelocity + GRAVITY
        character.y = character.y + jumpVelocity

        -- Check ground
        if character.y >= MIN_Y then
            character.y = MIN_Y
            isJumping = false
            jumpVelocity = 0
        end

        -- Check tiles
        local onTile, tileY = checkTileCollision(character, tiles)
        if onTile and jumpVelocity > 0 then
            character.y = tileY
            isJumping = false
            jumpVelocity = 0
        end

        newSequence = "jump"
    else
        -- Check if should fall
        local onTile = checkTileCollision(character, tiles)
        if not onTile and character.y < MIN_Y then
            isJumping = true
            jumpVelocity = 0
        end

        -- Animation sequences
        if moveX ~= 0 or moveY ~= 0 then
            if moveX > 0 and moveY == 0 then
                newSequence = "walkRight"
            elseif moveX < 0 and moveY == 0 then
                newSequence = "walkLeft"
            elseif moveX == 0 and moveY < 0 then
                newSequence = "walkUp"
            elseif moveX == 0 and moveY > 0 then
                newSequence = "walkDown"
            elseif moveX > 0 and moveY < 0 then
                newSequence = "walkUpRight"
            elseif moveX < 0 and moveY < 0 then
                newSequence = "walkUpLeft"
            elseif moveX > 0 and moveY > 0 then
                newSequence = "walkDownRight"
            elseif moveX < 0 and moveY > 0 then
                newSequence = "walkDownLeft"
            end
        end
    end

    -- Change sequence
    if newSequence and currentSequence ~= newSequence then
        character:setSequence(newSequence)
        currentSequence = newSequence
        character:play()
    end

    -- Set scale
    if not isJumping then
        if moveX > 0 then
            character.xScale = 0.5
        elseif moveX < 0 then
            character.xScale = -0.5
        end
    end

    -- Move character
    if moveX ~= 0 then
        character.x = character.x + moveX
        if not isJumping then
            character:play()
        end
    elseif moveY ~= 0 and not isJumping then
        local newY = character.y + moveY
        if newY < MIN_Y then newY = MIN_Y end
        if newY > MAX_Y then newY = MAX_Y end
        character.y = newY
        character:play()
    else
        if not isJumping then
            character:pause()
        end
    end

    return currentSequence
end

return playerMovement