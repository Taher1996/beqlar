-- Menu Scene (Korjattu versio)
-- MenuScenen luominen composer-järjestelmällä
local composer = require("composer")
local scene = composer.newScene()

function scene:create(event)
    local sceneGroup = self.view

    -- Näytön dimensiot (leveys ja korkeus)
    local screenW = display.contentWidth
    local screenH = display.contentHeight

    -- Taustakuva
    local backGround = display.newImageRect("images/muutkuvat/paav/pvdr.png", screenW, screenH)
    backGround.x = display.contentCenterX
    backGround.y = display.contentCenterY
    sceneGroup:insert(backGround)

    -- Start nappi (uusi kuva)
    local startButton = display.newImageRect("images/muutkuvat/rakennukset/Start.png", 200, 60)
    startButton.x = display.contentCenterX
    startButton.y = display.contentCenterY - 80
    sceneGroup:insert(startButton)

    -- Intro nappi - oma muotoilu ilman kuvaa (KESKELLÄ RUUTUA)
    local storyButton = display.newRoundedRect(display.contentCenterX, display.contentCenterY + 20, 200, 60, 8)
    storyButton:setFillColor(0.1, 0.1, 0.15)
    storyButton.strokeWidth = 2
    storyButton:setStrokeColor(1, 0.8, 0)
    sceneGroup:insert(storyButton)

    local storyButtonText = display.newText("Intro", display.contentCenterX, display.contentCenterY + 20, native.systemFont, 24)
    storyButtonText:setFillColor(1, 0.8, 0)
    sceneGroup:insert(storyButtonText)

    -- Quit nappi (uusi kuva)
    local quitButton = display.newImageRect("images/muutkuvat/rakennukset/Quit.png", 200, 60)
    quitButton.x = display.contentCenterX
    quitButton.y = display.contentCenterY + 120
    sceneGroup:insert(quitButton)

    -- Ääni-ikoni
    local soundIcon = display.newRect(screenW - 50, 50, 60, 60)
    soundIcon:setFillColor(0.3, 0.3, 0.3)
    sceneGroup:insert(soundIcon)

    local soundText = display.newText("🔊", screenW - 50, 50, native.systemFont, 36)
    soundText:setFillColor(1, 1, 1)
    sceneGroup:insert(soundText)

    -- Funktio intro popup-ikkunan näyttämiseen
    local function showStoryPopup()
        -- Tumma tausta
        local popupBg = display.newRect(display.contentCenterX, display.contentCenterY, screenW, screenH)
        popupBg:setFillColor(0, 0, 0, 0.7)
        sceneGroup:insert(popupBg)

        -- Popup ikkuna
        local popup = display.newRoundedRect(display.contentCenterX, display.contentCenterY, screenW - 60, screenH - 120, 15)
        popup:setFillColor(0.2, 0.2, 0.3)
        popup.strokeWidth = 3
        popup:setStrokeColor(1, 0.8, 0)
        sceneGroup:insert(popup)

        -- Pelin tarina teksti popup-ikkunassa
        local storyText = display.newText({
            text = "Intro\n" ..
                   "Drunken Night is a short platformer about how a single bad night can spiral out of control. " ..
                   "Thrown out of a bar after a fight with the bouncer, the protagonist discovers his wallet is missing.",
            x = display.contentCenterX,
            y = display.contentCenterY - 80,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 16,
            align = "center"
        })
        storyText:setFillColor(1, 0.8, 0)  -- Keltainen highlight
        sceneGroup:insert(storyText)

        -- Scene one teksti
        local sceneOneText = display.newText({
            text = "Scene One - The Bar",
            x = display.contentCenterX,
            y = display.contentCenterY - 10,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 18,
            align = "center"
        })
        sceneOneText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(sceneOneText)

        -- Hint teksti Scene One
        local hintText = display.newText({
            text = "Hint: You need to collect, but what? Discover it yourself!",
            x = display.contentCenterX,
            y = display.contentCenterY + 30,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 14,
            align = "center"
        })
        hintText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(hintText)

        -- Scene two teksti
        local sceneTwoText = display.newText({
            text = "Scene - Street",
            x = display.contentCenterX,
            y = display.contentCenterY + 70,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 18,
            align = "center"
        })
        sceneTwoText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(sceneTwoText)

        -- Hint teksti Scene Two
        local hintText2 = display.newText({
            text = "Hint: Speed, and the swiftness for survival",
            x = display.contentCenterX,
            y = display.contentCenterY + 110,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 14,
            align = "center"
        })
        hintText2:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(hintText2)

        -- Sulje nappi
        local closeButton = display.newRoundedRect(display.contentCenterX, display.contentCenterY + 180, 120, 50, 8)
        closeButton:setFillColor(0.8, 0.2, 0.2)
        sceneGroup:insert(closeButton)

        local closeText = display.newText("CLOSE", display.contentCenterX, display.contentCenterY + 180, native.systemFont, 20)
        closeText:setFillColor(1, 1, 1)
        sceneGroup:insert(closeText)

        -- Sulje nappin käsittelijä
        local function onClosePress(event)
            if event.phase == "ended" then
                display.remove(popupBg)
                display.remove(popup)
                display.remove(storyText)
                display.remove(sceneOneText)
                display.remove(hintText)
                display.remove(sceneTwoText)
                display.remove(hintText2)
                display.remove(closeButton)
                display.remove(closeText)
            end
            return true
        end

        closeButton:addEventListener("touch", onClosePress)
    end

    -- Start napin painamisen käsittelijä
    local function onStartButtonPress(event)
        if event.phase == "ended" then
            -- Siirtyminen pelin pääsceneen
            composer.gotoScene("scenes.scene_main", {effect = "slideLeft", time = 300})
        end
        return true
    end

    -- Quit napin painamisen käsittelijä
    local function onQuitButtonPress(event)
        if event.phase == "ended" then
            -- Pelin sulkeminen
            native.requestExit()
        end
        return true
    end

    -- Intro napin painamisen käsittelijä
    local function onIntroButtonPress(event)
        if event.phase == "ended" then
            showStoryPopup()
        end
        return true
    end

    -- Ääni-ikonin painamisen käsittelijä
    local function onSoundIconPress(event)
        if event.phase == "ended" then
            print("Ääni asetukset (tulossa myöhemmin)")
        end
        return true
    end

    -- Lisää kuuntelijat napeille
    startButton:addEventListener("touch", onStartButtonPress)
    quitButton:addEventListener("touch", onQuitButtonPress)
    storyButton:addEventListener("touch", onIntroButtonPress)
    soundIcon:addEventListener("touch", onSoundIconPress)
end

scene:addEventListener("create", scene)

return scene