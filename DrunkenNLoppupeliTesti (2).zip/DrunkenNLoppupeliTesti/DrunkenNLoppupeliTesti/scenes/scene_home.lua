-- scene_home.lua
-- Home scene - Kotiin tuleva cutscene

local composer = require("composer")
local scene = composer.newScene()

function scene:create(event)
    local sceneGroup = self.view

    -- Hae näytön dimensiot
    local screenW = display.contentWidth
    local screenH = display.contentHeight
    
    print("=== SCENE_HOME CREATE START ===")

    -- Lataa talo kuva
    print("Ladataan talo-kuvaa...")
    local talo = display.newImageRect("images/talo.png", 400, 400)
    talo.x = display.contentCenterX
    talo.y = display.contentCenterY + 100
    sceneGroup:insert(talo)
    print("Talo ladattu OK")

    -- Lataa pelaajan sprite
    print("Ladataan pelaajan sprite-kuvaa...")
    local walkOptions = require("images.123newch")
    local walkSheet = graphics.newImageSheet("images/123newch.png", walkOptions)
    print("Sprite sheet ladattu OK")
    
    -- Luo sprite kävelyn animaatiolla
    local drunkenguy = display.newSprite(walkSheet, {
        { name="walkRight", frames={1,2,3,4,5}, time=800, loopCount=0 },
    })
    drunkenguy.x = -100  -- Aloita vasemmalta puolelta ruudun ulkopuolelta
    drunkenguy.y = screenH - 100
    drunkenguy.xScale = 0.5
    drunkenguy.yScale = 0.5
    drunkenguy:setSequence("walkRight")
    drunkenguy:play()
    sceneGroup:insert(drunkenguy)
    print("Pelaajan sprite luotu OK")

    -- Luo cutscene-teksti (alkaa näkymättömänä)
    print("Luodaan teksti...")
    local cutsceneText = display.newText({
        text = "Home sweet home...",
        x = screenW/2,
        y = 100,
        width = screenW - 100,
        font = native.systemFont,
        fontSize = 32,
        align = "center"
    })
    cutsceneText:setFillColor(1, 1, 1)  -- Valkoinen teksti
    cutsceneText.alpha = 0  -- Aloita näkymättömänä
    sceneGroup:insert(cutsceneText)
    print("Teksti luotu OK")

    print("Aloitetaan animaatio...")
    -- Animaatio - pelaaja kävelee keskelle
    transition.to(drunkenguy, {
        time = 3000,
        x = screenW/2,
        onComplete = function()
            print("Pelaaja saapui keskelle")
            -- Pysäytä animaatio ja näytä teksti
            drunkenguy:pause()
            
            -- Näytä teksti fade in
            transition.to(cutsceneText, {
                time = 800,
                alpha = 1,
                onComplete = function()
                    print("Teksti näkyvissä")
                    -- Odota 2 sekuntia ja sitten fade out sekä mene menu-näyttöön
                    timer.performWithDelay(2000, function()
                        print("Aloitetaan lopullinen fade out...")
                        transition.to(cutsceneText, {
                            time = 800,
                            alpha = 0
                        })
                        transition.to(drunkenguy, {
                            time = 800,
                            alpha = 0
                        })
                        transition.to(talo, {
                            time = 800,
                            alpha = 0,
                            onComplete = function()
                                print("Mennään menu-näyttöön...")
                                composer.gotoScene("scenes.scene_menu", {
                                    effect = "fade",
                                    time = 500
                                })
                            end
                        })
                    end)
                end
            })
        end
    })
    print("Animaatio aloitettu OK")

    self.cutsceneText = cutsceneText
    self.drunkenguy = drunkenguy
    self.talo = talo
    
    print("=== SCENE_HOME CREATE END ===")
end

function scene:show(event)
    -- Cutscene pelaa automaattisesti
end

function scene:hide(event)
    local phase = event.phase

    if phase == "will" then
        -- Peruuta kaikki transitiot
        transition.cancel(self.drunkenguy)
        transition.cancel(self.cutsceneText)
        transition.cancel(self.talo)
    end
end

function scene:destroy(event)
    -- Siivous jos tarpeen
end

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)
scene:addEventListener("hide", scene)
scene:addEventListener("destroy", scene)

return scene