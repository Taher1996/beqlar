return {
    width = 640,
    height = 360,
    numFrames = 7,
    frames = {
        {
            x = 0,
            y = 0,
            width = 640,
            height = 360
        },
        {
            x = 640,
            y = 0,
            width = 640,
            height = 360
        },
        {
            x = 0,
            y = 360,
            width = 640,
            height = 360
        },
        {
            x = 640,
            y = 360,
            width = 640,
            height = 360
        },
        {
            x = 0,
            y = 720,
            width = 640,
            height = 360
        },
        {
            x = 640,
            y = 720,
            width = 640,
            height = 360
        },
        {
            x = 0,
            y = 1080,
            width = 640,
            height = 360
        }
    }
}