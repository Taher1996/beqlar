-- Menu Scene (Korjattu versio)
-- MenuScenen luominen composer-järjestelmällä
local composer = require("composer")
local scene = composer.newScene()

function scene:create(event)
    local sceneGroup = self.view

    -- Näytön dimensiot (leveys ja korkeus)
    local screenW = display.contentWidth
    local screenH = display.contentHeight

    -- Taustakuva
    local backGround = display.newImageRect("images/muutkuvat/paav/pvdr.png", screenW, screenH)
    backGround.x = display.contentCenterX
    backGround.y = display.contentCenterY
    sceneGroup:insert(backGround)

    -- Start nappi (uusi kuva)
    local startButton = display.newImageRect("images/muutkuvat/rakennukset/Start.png", 200, 60)
    startButton.x = display.contentCenterX
    startButton.y = display.contentCenterY - 80
    sceneGroup:insert(startButton)

    -- Intro nappi - oma muotoilu ilman kuvaa (KESKELLÄ RUUTUA)
    local storyButton = display.newRoundedRect(display.contentCenterX, display.contentCenterY + 20, 200, 60, 8)
    storyButton:setFillColor(0.1, 0.1, 0.15)
    storyButton.strokeWidth = 2
    storyButton:setStrokeColor(1, 0.8, 0)
    sceneGroup:insert(storyButton)

    local storyButtonText = display.newText("Intro", display.contentCenterX, display.contentCenterY + 20, native.systemFont, 24)
    storyButtonText:setFillColor(1, 0.8, 0)
    sceneGroup:insert(storyButtonText)

    -- Quit nappi (uusi kuva)
    local quitButton = display.newImageRect("images/muutkuvat/rakennukset/Quit.png", 200, 60)
    quitButton.x = display.contentCenterX
    quitButton.y = display.contentCenterY + 120
    sceneGroup:insert(quitButton)

    -- Ääni-ikoni
    local soundIcon = display.newRect(screenW - 50, 50, 60, 60)
    soundIcon:setFillColor(0.3, 0.3, 0.3)
    sceneGroup:insert(soundIcon)

    local soundText = display.newText("🔊", screenW - 50, 50, native.systemFont, 36)
    soundText:setFillColor(1, 1, 1)
    sceneGroup:insert(soundText)

    -- Äänenvoimakkuuden säätöjärjestelmä (alussa piilotettu)
    local volumePanel = display.newRoundedRect(screenW - 50, 150, 100, 200, 10)
    volumePanel:setFillColor(0.2, 0.2, 0.3)
    volumePanel.strokeWidth = 2
    volumePanel:setStrokeColor(1, 0.8, 0)
    sceneGroup:insert(volumePanel)
    volumePanel.isVisible = false

    -- Voimakkuuden slider PALLO (ei neliö)
    local volumeSlider = display.newCircle(screenW - 50, 150, 8)
    volumeSlider:setFillColor(1, 0.8, 0)
    sceneGroup:insert(volumeSlider)
    volumeSlider.isVisible = false
    volumeSlider.y = 150  -- Alussa 50% (keskellä)

    -- Voimakkuusarvo teksti
    local volumeValue = display.newText("50%", screenW - 50, 280, native.systemFont, 16)
    volumeValue:setFillColor(1, 0.8, 0)
    sceneGroup:insert(volumeValue)
    volumeValue.isVisible = false

    -- Globaali muuttuja äänenvoimakkuudelle
    local currentVolume = 0.5

    -- Funktio äänenvoimakkuuden asettamiselle
    local function setVolume(volume)
        if volume < 0 then volume = 0 end
        if volume > 1 then volume = 1 end
        currentVolume = volume
        audio.setVolume(currentVolume, {channel = 1})
        volumeValue.text = math.floor(currentVolume * 100) .. "%"
        volumeSlider.y = 100 + (1 - currentVolume) * 150  -- Invertoitu (ylös = enemmän)
    end

    -- Funktio intro popup-ikkunan näyttämiseen
    local function showStoryPopup()
        -- Tumma tausta
        local popupBg = display.newRect(display.contentCenterX, display.contentCenterY, screenW, screenH)
        popupBg:setFillColor(0, 0, 0, 0.7)
        sceneGroup:insert(popupBg)

        -- Popup ikkuna (pienempi kuin aiemmin)
        local popup = display.newRoundedRect(display.contentCenterX, display.contentCenterY, screenW - 40, screenH - 150, 15)
        popup:setFillColor(0.2, 0.2, 0.3)
        popup.strokeWidth = 3
        popup:setStrokeColor(1, 0.8, 0)
        sceneGroup:insert(popup)

        -- Pelin tarina teksti popup-ikkunassa
        local storyText = display.newText({
            text = "Intro\n" ..
                   "Drunken Night is a short platformer about how a single bad night can spiral out of control. " ..
                   "Thrown out of a bar after a fight with the bouncer, the protagonist discovers his wallet is missing.",
            x = display.contentCenterX,
            y = display.contentCenterY - 100,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 14,
            align = "center"
        })
        storyText:setFillColor(1, 0.8, 0)  -- Keltainen highlight
        sceneGroup:insert(storyText)

        -- Scene one teksti
        local sceneOneText = display.newText({
            text = "Scene One - The Bar",
            x = display.contentCenterX,
            y = display.contentCenterY - 60,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 18,
            align = "center"
        })
        sceneOneText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(sceneOneText)

        -- Hint teksti Scene One
        local hintText = display.newText({
            text = "Hint: You need to collect, but what? Discover it yourself!",
            x = display.contentCenterX,
            y = display.contentCenterY - 20,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 14,
            align = "center"
        })
        hintText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(hintText)

        -- Scene Two teksti
        local sceneTwoText = display.newText({
            text = "Scene Two - Kiosk",
            x = display.contentCenterX,
            y = display.contentCenterY + 20,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 18,
            align = "center"
        })
        sceneTwoText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(sceneTwoText)

        -- Hint teksti Scene Two
        local hintText2 = display.newText({
            text = "Hint: Try to get rid of your hunger",
            x = display.contentCenterX,
            y = display.contentCenterY + 60,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 14,
            align = "center"
        })
        hintText2:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(hintText2)

        -- Scene Three teksti
        local sceneThreeText = display.newText({
            text = "Scene Three - Street",
            x = display.contentCenterX,
            y = display.contentCenterY + 100,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 18,
            align = "center"
        })
        sceneThreeText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(sceneThreeText)

        -- Hint teksti Scene Three
        local hintText3 = display.newText({
            text = "Hint: Speed, and the swiftness for survival",
            x = display.contentCenterX,
            y = display.contentCenterY + 140,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 14,
            align = "center"
        })
        hintText3:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(hintText3)

        -- Scene Four teksti
        local sceneFourText = display.newText({
            text = "Scene Four - Home",
            x = display.contentCenterX,
            y = display.contentCenterY + 180,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 18,
            align = "center"
        })
        sceneFourText:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(sceneFourText)

        -- Hint teksti Scene Four
        local hintText4 = display.newText({
            text = "Hint: It's mysterious but you want to get there",
            x = display.contentCenterX,
            y = display.contentCenterY + 220,
            width = screenW - 100,
            font = native.systemFont,
            fontSize = 14,
            align = "center"
        })
        hintText4:setFillColor(1, 0.8, 0)  -- Keltainen
        sceneGroup:insert(hintText4)

        -- Sulje nappi
        local closeButton = display.newRoundedRect(display.contentCenterX, display.contentCenterY + 280, 120, 50, 8)
        closeButton:setFillColor(0.8, 0.2, 0.2)
        sceneGroup:insert(closeButton)

        local closeText = display.newText("CLOSE", display.contentCenterX, display.contentCenterY + 280, native.systemFont, 20)
        closeText:setFillColor(1, 1, 1)
        sceneGroup:insert(closeText)

        -- Sulje nappin käsittelijä
        local function onClosePress(event)
            if event.phase == "ended" then
                display.remove(popupBg)
                display.remove(popup)
                display.remove(storyText)
                display.remove(sceneOneText)
                display.remove(hintText)
                display.remove(sceneTwoText)
                display.remove(hintText2)
                display.remove(sceneThreeText)
                display.remove(hintText3)
                display.remove(sceneFourText)
                display.remove(hintText4)
                display.remove(closeButton)
                display.remove(closeText)
            end
            return true
        end

        closeButton:addEventListener("touch", onClosePress)
    end

    -- Start napin painamisen käsittelijä
    local function onStartButtonPress(event)
        if event.phase == "ended" then
            -- Siirtyminen pelin pääsceneen
            composer.gotoScene("scenes.scene_main", {effect = "slideLeft", time = 300})
        end
        return true
    end

    -- Quit napin painamisen käsittelijä
    local function onQuitButtonPress(event)
        if event.phase == "ended" then
            -- Pelin sulkeminen
            native.requestExit()
        end
        return true
    end

    -- Intro napin painamisen käsittelijä
    local function onIntroButtonPress(event)
        if event.phase == "ended" then
            showStoryPopup()
        end
        return true
    end

    -- Ääni-ikonin painamisen käsittelijä
    local function onSoundIconPress(event)
        if event.phase == "ended" then
            -- Näytä/piilota volume panel
            volumePanel.isVisible = not volumePanel.isVisible
            volumeSlider.isVisible = not volumeSlider.isVisible
            volumeValue.isVisible = not volumeValue.isVisible
        end
        return true
    end

    -- Slider:n vetämisen käsittelijä
    local function onSliderDrag(event)
        local slider = event.target
        if event.phase == "began" then
            -- Aloita vetäminen
            display.getCurrentStage():setFocus(slider)
        elseif event.phase == "moved" then
            -- Aseta slider y-koordinaattia rajoja noudattaen (pysyy paneelin sisällä)
            local minY = 55   -- Paneelin ylä-raja
            local maxY = 245  -- Paneelin ala-raja
            slider.y = math.max(minY, math.min(maxY, event.y))

            -- Laske voimakkuus slider-positiosta
            local newVolume = 1 - (slider.y - minY) / (maxY - minY)
            setVolume(newVolume)
        elseif event.phase == "ended" or event.phase == "cancelled" then
            -- Lopeta vetäminen
            display.getCurrentStage():setFocus(nil)
        end
        return true
    end

    volumeSlider:addEventListener("touch", onSliderDrag)

    -- Lisää kuuntelijat napeille
    startButton:addEventListener("touch", onStartButtonPress)
    quitButton:addEventListener("touch", onQuitButtonPress)
    storyButton:addEventListener("touch", onIntroButtonPress)
    soundIcon:addEventListener("touch", onSoundIconPress)
end

function scene:show(event)
    if event.phase == "did" then
        -- Soita tausta musiikkia 50% voimakkuudella
        audio.stop()
        local bgMusic = audio.loadSound("sounds/takeover.mp3")
        audio.play(bgMusic, {loops = -1, channel = 1})
        audio.setVolume(0.5, {channel = 1})
    end
end

scene:addEventListener("create", scene)
scene:addEventListener("show", scene)

return scene