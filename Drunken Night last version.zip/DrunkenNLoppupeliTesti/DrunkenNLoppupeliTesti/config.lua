-- config.lua
-- Pelin konfiguraatiotiedosto

application =
{
	-- Näytön asetukset
	content =
	{
		width = 640,      -- Näytön leveys
		height = 960,     -- Näytön korkeus
		scale = "letterbox", -- Skaalausmoodi
		fps = 60,         -- Kuvataulukkohinta (fps)

		--[[
		-- Vaihtoehtoisia kuvaresoluutioita eri laitteille
		imageSuffix =
		{
			    ["@2x"] = 2,
			    ["@4x"] = 4,
		},
		--]]
	},
}

