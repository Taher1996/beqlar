HEY!
this is final test work, it works 100%.(the dialogs are temporary ones-------
-----------------------------------------------------------------------------

It's impossible to finish the game, Unless you will change some options by yourself (here's the hint--Try to change jump gravity, and the speed, once you done that you will be able to finish the GAME, it's still a hard task.. :), I I already made it easy for letting you pass first room(bar) to the kiosk for free ^^..

-----------------------------------------------------------------------------

The keys for movements is found on the top left - when you click the lamp!

Anyway best of luck!
